﻿namespace Assignment3
{
    partial class Assignment3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Assignment3));
            dealButton = new Button();
            saveHand = new Button();
            loadHand = new Button();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            cards = new ImageList(components);
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // dealButton
            // 
            dealButton.Location = new Point(149, 141);
            dealButton.Margin = new Padding(6);
            dealButton.Name = "dealButton";
            dealButton.Size = new Size(189, 58);
            dealButton.TabIndex = 0;
            dealButton.Text = "&Deal";
            dealButton.UseVisualStyleBackColor = true;
            dealButton.Click += dealButton_Click;
            // 
            // saveHand
            // 
            saveHand.Location = new Point(793, 141);
            saveHand.Margin = new Padding(6);
            saveHand.Name = "saveHand";
            saveHand.Size = new Size(189, 58);
            saveHand.TabIndex = 1;
            saveHand.Text = "&Save Hand";
            saveHand.UseVisualStyleBackColor = true;
            // 
            // loadHand
            // 
            loadHand.Location = new Point(1072, 141);
            loadHand.Margin = new Padding(6);
            loadHand.Name = "loadHand";
            loadHand.Size = new Size(189, 58);
            loadHand.TabIndex = 2;
            loadHand.Text = "&Load Hand";
            loadHand.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(104, 870);
            checkBox1.Margin = new Padding(6);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(28, 27);
            checkBox1.TabIndex = 3;
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(411, 849);
            checkBox2.Margin = new Padding(6);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(28, 27);
            checkBox2.TabIndex = 4;
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(686, 849);
            checkBox3.Margin = new Padding(6);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(28, 27);
            checkBox3.TabIndex = 5;
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(922, 849);
            checkBox4.Margin = new Padding(6);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(28, 27);
            checkBox4.TabIndex = 6;
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(1233, 849);
            checkBox5.Margin = new Padding(6);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(28, 27);
            checkBox5.TabIndex = 7;
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // cards
            // 
            cards.ColorDepth = ColorDepth.Depth32Bit;
            cards.ImageStream = (ImageListStreamer)resources.GetObject("cards.ImageStream");
            cards.TransparentColor = Color.Transparent;
            cards.Images.SetKeyName(0, "p2.png");
            cards.Images.SetKeyName(1, "p7.png");
            cards.Images.SetKeyName(2, "p13.png");
            cards.Images.SetKeyName(3, "p16.png");
            cards.Images.SetKeyName(4, "p26.png");
            cards.Images.SetKeyName(5, "p31.png");
            cards.Images.SetKeyName(6, "p32.png");
            cards.Images.SetKeyName(7, "p36.png");
            cards.Images.SetKeyName(8, "p37.png");
            cards.Images.SetKeyName(9, "p47.png");
            cards.Images.SetKeyName(10, "p0.png");
            cards.Images.SetKeyName(11, "p1.png");
            cards.Images.SetKeyName(12, "p3.png");
            cards.Images.SetKeyName(13, "p4.png");
            cards.Images.SetKeyName(14, "p5.png");
            cards.Images.SetKeyName(15, "p6.png");
            cards.Images.SetKeyName(16, "p8.png");
            cards.Images.SetKeyName(17, "p9.png");
            cards.Images.SetKeyName(18, "p10.png");
            cards.Images.SetKeyName(19, "p11.png");
            cards.Images.SetKeyName(20, "p12.png");
            cards.Images.SetKeyName(21, "p14.png");
            cards.Images.SetKeyName(22, "p15.png");
            cards.Images.SetKeyName(23, "p17.png");
            cards.Images.SetKeyName(24, "p18.png");
            cards.Images.SetKeyName(25, "p19.png");
            cards.Images.SetKeyName(26, "p20.png");
            cards.Images.SetKeyName(27, "p21.png");
            cards.Images.SetKeyName(28, "p22.png");
            cards.Images.SetKeyName(29, "p23.png");
            cards.Images.SetKeyName(30, "p24.png");
            cards.Images.SetKeyName(31, "p25.png");
            cards.Images.SetKeyName(32, "p27.png");
            cards.Images.SetKeyName(33, "p28.png");
            cards.Images.SetKeyName(34, "p29.png");
            cards.Images.SetKeyName(35, "p30.png");
            cards.Images.SetKeyName(36, "p33.png");
            cards.Images.SetKeyName(37, "p34.png");
            cards.Images.SetKeyName(38, "p35.png");
            cards.Images.SetKeyName(39, "p38.png");
            cards.Images.SetKeyName(40, "p39.png");
            cards.Images.SetKeyName(41, "p40.png");
            cards.Images.SetKeyName(42, "p41.png");
            cards.Images.SetKeyName(43, "p42.png");
            cards.Images.SetKeyName(44, "p43.png");
            cards.Images.SetKeyName(45, "p44.png");
            cards.Images.SetKeyName(46, "p45.png");
            cards.Images.SetKeyName(47, "p46.png");
            cards.Images.SetKeyName(48, "p48.png");
            cards.Images.SetKeyName(49, "p49.png");
            cards.Images.SetKeyName(50, "p50.png");
            cards.Images.SetKeyName(51, "p51.png");
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(47, 269);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 181);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(316, 260);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(200, 183);
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(600, 269);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(200, 181);
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Location = new Point(830, 269);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(200, 181);
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(1124, 280);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(200, 163);
            pictureBox5.TabIndex = 12;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // Assignment3
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1486, 960);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(loadHand);
            Controls.Add(saveHand);
            Controls.Add(dealButton);
            Margin = new Padding(6);
            Name = "Assignment3";
            Text = "Poker Hand Simulator";
            Load += Assignment3_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button dealButton;
        private Button saveHand;
        private Button loadHand;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private ImageList cards;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
    }
}
